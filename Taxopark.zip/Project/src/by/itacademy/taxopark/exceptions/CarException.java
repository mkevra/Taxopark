package by.itacademy.taxopark.exceptions;

public class CarException extends Exception {
    public CarException(String message) {
        super(message);
    }
}
