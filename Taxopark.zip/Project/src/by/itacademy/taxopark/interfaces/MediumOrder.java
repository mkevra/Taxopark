package by.itacademy.taxopark.interfaces;

public interface MediumOrder {
}
